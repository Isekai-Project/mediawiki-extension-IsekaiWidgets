## 预览卡片设计
```html
<previewCard>
    [[链接1]]
    [[链接2]]
</previewCard>
<previewCard>
    <categorytree mode="pages" depth="1" hideroot="on" showcount="on" />
</previewCard>
```
